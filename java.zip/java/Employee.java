package com.company;

public interface Emp extends Per {
    void work();
}
