package com.company;

public interface Develop extends Per {
    void develop();
}
