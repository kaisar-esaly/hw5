package com.company;

public interface FrontDevelop extends Develop {
    void writeFront();
}
