package com.company;

public interface BackDevelop extends Develop {
    void writeBack();
}
