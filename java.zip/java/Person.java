package com.company;

public interface Per {
    String getName();
    void setName(String name);
}
