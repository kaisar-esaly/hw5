package com.company;

public interface Prinosit {
    void makeTea();
}
