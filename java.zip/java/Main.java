package com.company;

public class Main {

    public static void main(String[] args) {
        Company company = new Company();
        company.addEmployee(new JaDevelop("Ainaddin"));
        company.addEmployee(new JaDevelop("Maratuly"));
        company.addEmployee(new JavascrDevelop("Ainaddin"));
        company.addEmployee(new FullDevelop("Maratuly"));

        company.startWork();
    }
}
